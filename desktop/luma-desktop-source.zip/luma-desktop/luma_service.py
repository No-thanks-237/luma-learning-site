"""Independent transparent Luma companion. Loopback finite commands only."""
import argparse,json,logging,os,secrets,sys
from pathlib import Path
from dataclasses import dataclass,field
from threading import Event,Thread
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from bridge_protocol import APP_ID,PROTOCOL,DEFAULT_PORT,DEFAULT_ORIGINS,local_origin,request_allowed,validate_command
os.environ.setdefault('QT_ENABLE_HIGHDPI_SCALING','1')
from PyQt5.QtCore import QObject,pyqtSignal,QTimer
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication,QSystemTrayIcon,QMenu
from desktop_pet.luma_window import LumaWindow
ROOT=Path(__file__).resolve().parent
@dataclass
class Request:
    command:dict
    done:Event=field(default_factory=Event)
    result:dict=field(default_factory=dict)
class Controller(QObject):
    requested=pyqtSignal(object)
    def __init__(self,pet):super().__init__();self.pet=pet;self.requested.connect(self.apply)
    def call(self,command):
        req=Request(command);self.requested.emit(req)
        if not req.done.wait(4):return {'ok':False,'error':'露米暂未响应，请重试'}
        return req.result
    def apply(self,req):
        try:
            action=req.command['action'];pet=self.pet
            if action=='show':pet.show_luma()
            elif action=='hide':pet.hide()
            elif action=='interact':pet.show_luma();pet.trigger_random_interaction()
            elif action in ('focus','rest'):
                pet.focus_mode=action=='focus';pet._apply_quiet()
                if pet.isVisible():pet._show_bubble('这一轮慢慢来，露米陪着你。' if pet.focus_mode else '这一轮完成了，看看远处再继续吧。',pet.pos())
            elif action=='resize':pet.set_scale(req.command['value'])
            elif action=='topmost':pet.set_topmost(req.command['value'])
            elif action=='quiet':pet.set_quiet(req.command['value'])
            elif action=='reset':pet.set_scale(1);pet.recover()
            elif action=='recover':pet.recover()
            req.result={'ok':True,'app_id':APP_ID,'protocol':PROTOCOL,'desktop':True,'visible':pet.isVisible(),'name':'露米','scale':pet.scale,'topmost':pet.always_on_top,'quiet':pet.quiet,'focus':pet.focus_mode,'pid':os.getpid()}
        except Exception:
            logging.exception('pet action failed');req.result={'ok':False,'error':'桌宠操作未完成'}
        finally:req.done.set()
def make_handler(controller,origins,port,token):
    class Handler(BaseHTTPRequestHandler):
        def allowed(self):return request_allowed(self.headers.get('Host',''),self.headers.get('Origin'),origins,port)
        def send(self,code,value):
            raw=json.dumps(value,ensure_ascii=False).encode();self.send_response(code);origin=self.headers.get('Origin')
            if origin in origins:self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin')
            self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
        def do_OPTIONS(self):
            if not self.allowed() or self.path not in ('/command','/status'):return self.send(403,{'ok':False})
            self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.headers.get('Origin',''));self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS');self.send_header('Access-Control-Allow-Headers','Content-Type, X-Luma-Pet-Token')
            if self.headers.get('Access-Control-Request-Private-Network')=='true':self.send_header('Access-Control-Allow-Private-Network','true')
            self.end_headers()
        def do_GET(self):
            if not self.allowed():return self.send(403,{'ok':False})
            if self.path!='/status':return self.send(404,{'ok':False})
            result=controller.call({'action':'status'})
            if result.get('ok'):result['token']=token
            self.send(200,result)
        def do_POST(self):
            if not self.allowed() or self.path!='/command':return self.send(403,{'ok':False})
            if not secrets.compare_digest(self.headers.get('X-Luma-Pet-Token',''),token):return self.send(403,{'ok':False,'error':'请重新连接露米'})
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.send(415,{'ok':False})
            try:length=int(self.headers.get('Content-Length','0'))
            except ValueError:return self.send(400,{'ok':False})
            if not 0<length<=1024:return self.send(413,{'ok':False})
            try:command=validate_command(json.loads(self.rfile.read(length)))
            except (ValueError,UnicodeDecodeError):return self.send(400,{'ok':False,'error':'桌宠操作格式不正确'})
            result=controller.call(command);self.send(200 if result.get('ok') else 503,result)
        def log_message(self,*_):pass
    return Handler
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--show',action='store_true');parser.add_argument('--port',type=int,default=DEFAULT_PORT);args=parser.parse_args()
    if not 1024<=args.port<=65535:raise SystemExit('Invalid port')
    origins=DEFAULT_ORIGINS|{s for s in os.environ.get('LUMA_PET_ORIGINS','').split(',') if local_origin(s)}
    import urllib.request
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{args.port}/status',timeout=1) as response:state=json.load(response)
        if state.get('app_id')==APP_ID:
            if args.show:
                req=urllib.request.Request(f'http://127.0.0.1:{args.port}/command',data=b'{"action":"show"}',headers={'Content-Type':'application/json','X-Luma-Pet-Token':state['token']});urllib.request.urlopen(req,timeout=4).close()
            return
    except Exception:pass
    app=QApplication(sys.argv);app.setApplicationName('Luma Desktop');app.setQuitOnLastWindowClosed(False)
    image=ROOT/'assets/luma.png'
    if not image.exists():raise SystemExit('Missing Luma image')
    pet=LumaWindow(image);controller=Controller(pet)
    try:server=ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(controller,origins,args.port,secrets.token_urlsafe(32)))
    except OSError:raise SystemExit('Desktop pet port is occupied; no other application was stopped.')
    server.daemon_threads=True
    tray=QSystemTrayIcon(QIcon(str(image)),app);tray.setToolTip('露米 · 点击显示／收起，右键打开菜单')
    menu=QMenu();toggle=menu.addAction('显示／收起露米');toggle.triggered.connect(lambda:pet.hide() if pet.isVisible() else pet.show_luma())
    menu.addAction('找回露米／恢复拖动').triggered.connect(pet.recover)
    menu.addAction('和露米互动').triggered.connect(lambda:(pet.show_luma(),pet.trigger_random_interaction()))
    menu.addAction('恢复默认大小').triggered.connect(lambda:pet.set_scale(1))
    menu.addSeparator();menu.addAction('退出露米').triggered.connect(app.quit);tray.setContextMenu(menu)
    tray.activated.connect(lambda reason:(pet.hide() if pet.isVisible() else pet.show_luma()) if reason==QSystemTrayIcon.Trigger else None);tray.show()
    worker=Thread(target=server.serve_forever,daemon=True);worker.start()
    app.aboutToQuit.connect(lambda:pet.config_mgr.save_all(pet.pos(),pet.scale,pet.always_on_top))
    if args.show:QTimer.singleShot(0,pet.show_luma)
    try:app.exec_()
    finally:server.shutdown();server.server_close()
if __name__=='__main__':main()
