"""Render the same Luma SVG used by the web app for the native deskpet window."""

from pathlib import Path
import sys

from PyQt5.QtCore import QRectF
from PyQt5.QtGui import QPainter, QPixmap
from PyQt5.QtSvg import QSvgRenderer
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt


ASSETS = Path(__file__).resolve().parent / "assets"


def render() -> Path:
    app = QApplication.instance() or QApplication(sys.argv)
    source = ASSETS / "luma.svg"
    target = ASSETS / "luma.png"
    renderer = QSvgRenderer(str(source))
    if not renderer.isValid():
        raise RuntimeError(f"Cannot render {source}")
    image = QPixmap(680, 600)
    image.fill(Qt.transparent)
    painter = QPainter(image)
    painter.setRenderHint(QPainter.Antialiasing)
    renderer.render(painter, QRectF(0, 0, 680, 600))
    painter.end()
    if not image.save(str(target), "PNG"):
        raise RuntimeError(f"Cannot save {target}")
    _ = app
    return target


if __name__ == "__main__":
    print(render())
