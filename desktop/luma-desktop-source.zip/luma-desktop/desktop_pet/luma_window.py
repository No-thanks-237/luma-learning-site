"""Luma window built on supplied deskpet drag, animation and bubble engine."""
import math
from PyQt5.QtCore import Qt,QTimer,QPoint
from PyQt5.QtGui import QCursor,QTransform
from PyQt5.QtWidgets import QApplication,QMenu,QToolButton
from .pet_window import PetWindow
class LumaWindow(PetWindow):
    def __init__(self,image):
        super().__init__(str(image),{'露米':str(image)})
        self.setWindowTitle('露米 · Luma 桌面悬浮');self.setAttribute(Qt.WA_ShowWithoutActivating,True);self.label.setAttribute(Qt.WA_TransparentForMouseEvents,True)
        self.quiet=str(self.config_mgr.get('behavior/quiet',True)).lower() in ('true','1','yes');self.focus_mode=False;self._breath_step=0
        self._breath=QTimer(self);self._breath.setInterval(60);self._breath.timeout.connect(self._breathe)
        self.close_button=QToolButton(self);self.close_button.setText('×');self.close_button.setToolTip('收起到托盘，网页或托盘可再次显示');self.close_button.setFixedSize(23,23);self.close_button.clicked.connect(self.hide)
        self.close_button.setStyleSheet('QToolButton{color:#6e579a;background:#faf5ff;border:1px solid #d8c9eb;border-radius:11px;font-size:17px;}QToolButton:hover{background:#e9ddf8;}');self.close_button.hide()
        for screen in QApplication.screens():screen.availableGeometryChanged.connect(self.keep_on_screen)
        QApplication.instance().screenAdded.connect(lambda screen:screen.availableGeometryChanged.connect(self.keep_on_screen));QApplication.instance().screenRemoved.connect(lambda *_:self.keep_on_screen())
        self.hide();self._apply_quiet()
    def _screen_geometry(self):
        center=self.pos()+QPoint(self.width()//2,self.height()//2);screen=QApplication.screenAt(center)
        if not screen:screen=min(QApplication.screens(),key=lambda s:abs(s.availableGeometry().center().x()-center.x())+abs(s.availableGeometry().center().y()-center.y()))
        return screen.availableGeometry()
    def keep_on_screen(self,*_):self.move(self._clamp_to_screen(self.pos()));self.config_mgr.save_position(self.pos())
    def _snap_to_edge(self,pos):
        r=self._screen_geometry();x,y=pos.x(),pos.y()
        if abs(x-r.left())<self.EDGE_SNAP_DISTANCE:x=r.left()
        elif abs(x+self.width()-r.right()-1)<self.EDGE_SNAP_DISTANCE:x=r.right()-self.width()+1
        if abs(y-r.top())<self.EDGE_SNAP_DISTANCE:y=r.top()
        elif abs(y+self.height()-r.bottom()-1)<self.EDGE_SNAP_DISTANCE:y=r.bottom()-self.height()+1
        return self._clamp_to_screen(QPoint(x,y))
    def _breathe(self):
        if self._is_animating or self._is_dragging or not self.isVisible():return
        self._breath_step+=1;self._update_image_size();pix=self.label.pixmap()
        if pix:self.label.setPixmap(pix.transformed(QTransform().scale(1,1+.009*math.sin(self._breath_step*.12)),Qt.SmoothTransformation))
    def _apply_quiet(self):
        if self.quiet or self.focus_mode:self.idle_chat_timer.stop();self._wander_timer.stop()
        elif self.isVisible():self.idle_chat_timer.start();self._wander_timer.start()
    def set_quiet(self,value):self.quiet=value;self.config_mgr.set('behavior/quiet',value);self._apply_quiet()
    def set_scale(self,value):
        center=self.geometry().center();self._stop_pos_animations();self.scale=round(value,2);self._update_image_size();self.move(self._clamp_to_screen(center-QPoint(self.width()//2,self.height()//2)));self.config_mgr.save_all(self.pos(),self.scale,self.always_on_top)
    def set_topmost(self,value):
        was_visible=self.isVisible();pos=self.pos();self.always_on_top=value;self.config_mgr.save_always_on_top(value);self._init_window_flags()
        if was_visible:self.show();self.move(pos)
    def show_luma(self):self.show();self.keep_on_screen();self.raise_();self._apply_quiet()
    def recover(self):
        self.setAttribute(Qt.WA_TransparentForMouseEvents,False);self.setWindowFlag(Qt.WindowTransparentForInput,False);r=(QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry();self.move(r.right()-self.width()-30,r.bottom()-self.height()-30);self.show_luma()
    def enterEvent(self,event):self.close_button.move(max(0,self.width()-25),3);self.close_button.show();super().enterEvent(event)
    def leaveEvent(self,event):self.close_button.hide();super().leaveEvent(event)
    def showEvent(self,event):
        super().showEvent(event)
        if hasattr(self,'_breath'):self._breath.start();self._apply_quiet()
    def hideEvent(self,event):
        self._stop_pos_animations()
        if hasattr(self,'_breath'):self._breath.stop()
        super().hideEvent(event)
    def toggle_always_on_top(self):self.set_topmost(not self.always_on_top)
    def contextMenuEvent(self,event):
        menu=QMenu(self);menu.setStyleSheet('QMenu{background:#fffaff;color:#59466f;border:1px solid #ddd1ec;border-radius:9px;padding:6px;font-size:12px;}QMenu::item{padding:8px 20px;}QMenu::item:selected{background:#eee3f8;}')
        menu.addAction('和露米互动').triggered.connect(self.trigger_random_interaction);menu.addAction('放大').triggered.connect(lambda:self.set_scale(min(2.5,self.scale+.15)));menu.addAction('缩小').triggered.connect(lambda:self.set_scale(max(.5,self.scale-.15)));menu.addAction('恢复默认大小').triggered.connect(lambda:self.set_scale(1))
        top=menu.addAction('始终置顶');top.setCheckable(True);top.setChecked(self.always_on_top);top.triggered.connect(self.set_topmost)
        quiet=menu.addAction('安静陪伴');quiet.setCheckable(True);quiet.setChecked(self.quiet);quiet.triggered.connect(self.set_quiet)
        menu.addSeparator();menu.addAction('收起到托盘').triggered.connect(self.hide);menu.addAction('退出露米').triggered.connect(QApplication.quit);menu.exec_(event.globalPos())
