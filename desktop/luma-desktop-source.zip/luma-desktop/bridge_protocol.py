"""Finite local commands. No shell execution, file access or learning content."""
from urllib.parse import urlsplit
APP_ID='luma-desktop'
PROTOCOL=1
DEFAULT_PORT=43187
DEFAULT_ORIGINS={f'http://{h}:{p}' for h in ('localhost','127.0.0.1') for p in (5173,5174,8790,8791,8792)}
ACTIONS={'show','hide','interact','focus','rest','resize','topmost','quiet','reset','recover'}
def local_origin(value):
    try:
        u=urlsplit(value)
        return u.scheme=='http' and u.hostname in ('localhost','127.0.0.1') and bool(u.port) and not u.username and not u.password and u.path in ('','/') and not u.query and not u.fragment
    except (ValueError,TypeError):return False
def request_allowed(host,origin,allowed,port=DEFAULT_PORT):
    return host in {f'127.0.0.1:{port}',f'localhost:{port}'} and (origin is None or origin in allowed)
def validate_command(value):
    if not isinstance(value,dict) or set(value)-{'action','value'} or value.get('action') not in ACTIONS:raise ValueError('未知桌宠操作')
    action=value['action']
    if action=='resize':
        v=value.get('value')
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not .5<=v<=2.5:raise ValueError('大小范围为 50%–250%')
    elif action in ('topmost','quiet'):
        if not isinstance(value.get('value'),bool):raise ValueError('设置需要 true 或 false')
    elif 'value' in value:raise ValueError('此操作不接收其他内容')
    return value
