"""First-run installer; only installs pinned Qt dependency into this package."""
from pathlib import Path
import os, subprocess, sys
root=Path(__file__).resolve().parent
venv=root/'.runtime'/'python'
python=venv/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
if not python.exists():subprocess.run([sys.executable,'-m','venv',str(venv)],check=True)
if subprocess.run([str(python),'-c','import PyQt5.QtWidgets'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
    subprocess.run([str(python),'-m','pip','install','-r',str(root/'requirements.txt')],check=True)
windowless=python.with_name('pythonw.exe') if os.name=='nt' else python
subprocess.Popen([str(windowless),str(root/'luma_bridge.py'),'--show'],cwd=root,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
print('露米已启动。右键露米或系统托盘图标可退出。')
