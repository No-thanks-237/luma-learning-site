"""Compatibility entry point for the Luma desktop companion."""
from luma_service import main
if __name__ == '__main__':
    main()
