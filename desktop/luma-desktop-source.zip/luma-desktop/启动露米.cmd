@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python bootstrap.py) else (py -3 bootstrap.py)
if errorlevel 1 (echo Please install Python 3.10+ with pip, then retry. & pause)
